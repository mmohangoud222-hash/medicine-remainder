# MediTime — Medicine Reminder Website

A responsive medicine schedule tracker made with HTML, CSS, and vanilla JavaScript.

## Features
- Add, view, edit, and delete medicine records.
- Store medicine name, dosage, time, start date, end date, and optional notes.
- Dashboard with total medicine count, doses scheduled today, and earliest listed time.
- Schedule view sorted by time.
- Form validation and responsive design.
- Saves records in this browser using `localStorage`.

## Run the website
1. Download and extract `medicine_reminder_website.zip`.
2. Open the extracted `medicine_reminder_website` folder.
3. Double-click `index.html` to open it in Chrome, Edge, Firefox, or Safari.

Optional: in VS Code, open the folder and use the Live Server extension. Or run `python -m http.server 8000` in the folder and visit `http://localhost:8000`.

## Notes
- This is a front-end demo. It does not have a backend, account login, cloud database, or cross-device sync.
- It displays the schedule but does not send guaranteed alerts or notifications while closed.
- It is an organizational aid, not medical advice. Follow instructions from your healthcare professional.
- Records remain in the current browser until browser site data is cleared.
